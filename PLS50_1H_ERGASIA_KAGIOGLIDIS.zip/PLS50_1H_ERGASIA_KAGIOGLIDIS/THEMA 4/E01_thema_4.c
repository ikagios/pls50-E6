#include <stdlib.h>
#include <stdio.h>

main()
{
	int i,bus_seats,N; /* bus_seats: metablhth gia tis ueseis toy lewforeioy */
	                   /* i: metrhths, N: seires lewforeioy */
	FILE *bus;         /* arxeio bus */
	FILE *layout;      /* arexeio layout */
	char bus_sign, epilogh;  /* bus_sign: pinakida lewforeioy */
    bus=fopen("bus.txt","r");  /* anoigma toy arxeioy bus */
    if (bus==NULL)  /* Elegxos an h fopen eixe problhma na anoijei to arxeio */
    {
        puts("To arxeio den anoigei"); /* An exei problhma emfanizei mhnyma */
        exit(2);
    }
    for (i=1; i<=7; i++)
    {
        fscanf(bus,"%c",&bus_sign); /* Anagnwsh twn 7 prwtwn xarakthrwn toy arxeioy */
                                    /* dhl mono ths phnakidas */
        printf("%c",bus_sign);
    }
    for (i=8; i<=10; i++)
    {
        fscanf(bus,"%d",&bus_seats);/* Anagnwsh twn xarakthrwn apo 8 ews 10 toy arxeioy */
                                    /* dhl toy kenoy kai toy arithmoy twn thesewn */
        printf("% d",bus_seats); break;
    }
    puts("\n"); /* Allagh seiras */
    fclose(bus); /* Kleisimo arxeioy bus */
    if (((bus_seats-5)%4)!=0) /* Elegxos an o arithmos twn thesewn poy douhke symbadizei */
                              /* me thn katanomh 4xN+5. Gia na symbadizei prepei to */
                              /* ypoloipo ths diaireshs toy arithmoy twn uesewn ektos */
                              /* autwn ths galarias na einai mhden */
    {
        printf("O arithmos twn uesewn den symbadizei me\n");
        printf("thn problepomenh katanomh 4xN+5\n");
        puts("\n");
    }
    if (bus_seats>53) /* Elegxos an o arithmos twn uesewn poy douhke yperbainei tis 53 */
    {
        printf("To plhthos twn uesewn yperbainei tis 53\n");
        puts("\n");
    }
    printf("Pata enter gia emfanish toy menoy\n");
    int lewf[bus_seats];  /* Arxikopoihsh toy pinaka me tis ueseis toy lewforioy me oles tis */
                          /* ueseis 0 dhladh kenes */
    for (i=0; i<bus_seats; i++)
    {
        lewf[i]=0;
    }
    menu: /* Etiketa gia na epaneluoyme sto menoy meta apo kapoies epiloges */
    getchar(); /* Kata thn epanalhch toy menoy diabazei ton paramenonta xarakthra allaghs grammhs */
               /* apo thn prohgoumenh scanf kai ton apaloifei vste h epomenh scanf na diabasei ton */
               /* epiuymhto epomeno xarakthra (arithmo epiloghs) */
    printf("Diatiuentai oi akoloyues epiloges:\n");
    printf("1. Emfanish tou synolikoy plhthous kenwn uesewn kai twn arithmwn toys.\n");
    printf("2. Krathsh ueshs me sygkekrimeno arithmo.\n");
    printf("3. Krathsh ths prwths kenhs ueshs poy vrisketai se parathyro.\n");
    printf("4. Akyrwsh krathshs ueshs me sygkekrimeno arithmo.\n");
    printf("5. Anazhthsh an einai krathmenh h uesh me sygkekrimeno arithmo.\n");
    printf("6. Emfanish listas krathmenwn uesewn tajinomhmenhs kata arithmo ueshs.\n");
    printf("7. Emfanish ths pinakidas kykloforias kai toy diagrammatos toy lewforeioy.\n");
    printf("8. Apouhkeysh ths pinakidas kykloforias kai toy diagrammatos toy lewforeioy\n");
    printf("   se arxeio me onoma layout.txt.\n");
    printf("0. Termatismos toy programmatos.\n");
    puts("\n");
    printf("Dialeje mia apo tis anwterw epiloges: ");
    scanf("%c",&epilogh);             /* Eisagwgh epiloghs */
    if (epilogh>='0' && epilogh<='8') /* Elegxos an exei douei swsth epilogh dhl metajy 0 kai 8 */
    {
        if (epilogh=='1')
        {
            int ken_ues=0; /* Metablhth gia th methrhsh twn kenwn uesewn */
            printf("Oi arithmoi twn kenwn uesewn einai:");
            for (i=0; i<bus_seats; i++)
            {
                if (lewf[i]==0)  /* An h uesh i einai kenh */
                {
                    ken_ues++;   /* o metrhths aujanetai kata ena */
                    printf("%d ",i+1); /* H uesh toy pinaka antistoixei sthn epomenh uesh toy */
                                       /* lewforeioy */
                }
            }
            puts("\n");
            printf("O synolikos arithmos kenwn uesewn einai:%d\n",ken_ues);
            puts("\n"); goto menu; /* Phgainei sthn etiketa menu gia na janodouei to menoy */
        }
        else if (epilogh=='2')
        {
            int krat; /* Metablhth gia thn epiuymhth uesh krathshs */
            printf("Dwse th uesh poy ueleis na krathseis: ");
            scanf("%d",&krat);
            if (krat<=0 || krat>bus_seats) /* Elegxos an o arithmos poy douhke einai ektos oriwn */
            {
                printf("Edwses lathos arithmo ueshs.\n");
            }
            if (krat>0 && krat<=bus_seats && lewf[krat-1]==1) /* Elegxos an h uesh einai entos oriwn */
                                                              /* kai einai krathmenh */
            {
                printf("H uesh me aritmo %d einai krathmenh.\n",krat);
            }
            if (krat>0 && krat<=bus_seats && lewf[krat-1]==0) /* An h uesh einai entos oriwn kai den einai */
                                                              /* krathmenh, ginetai krathsh */
            {
                lewf[krat-1]=1;     /* An den einai krathmenh ginetai krathsh */
                printf("H uesh me arithmo %d einai pleon krathmenh\n",krat);
            }
            puts("\n");
            goto menu; /* Epanafora sto menoy */
        }
        else if (epilogh=='3')
        {
            int found=0; /* Metablhth poy ua deijei an vreuhke eleyuero parathyro */
                         /* wste na akoloyuhsei emfanish ths ueshs sthn ouonh */
            for (i=0; i<(bus_seats-4); i=i+4) /* Gia ta aristera parathyra ekkinoyme apo */
                         /* to mhden kai prosthetoyme kaue fora 4 ueseis gia ta epomena. */
                         /* Ejairoyntai oi 4 teleytaies ueseis ths galarias (bus_seats-4) */
            {
                if (lewf[i]==0) /* Elegxos an yparxei eleyuerh uesh se aristero parathyro */
                {
                    lewf[i]=1;
                    found=1; break; /* An den einai krathmenh, exoyme eyresh, ginetai krathsh */
                                    /* kai o vroxos diakoptetai */
                }
                if (lewf[i+3]==0) /* Elegxos an yparxei eleytherh uesh se deji parathyro */
                {
                    lewf[i+3]=1;
                    found=2; break; /* An den einai krathmenh, exoyme eyresh, ginetai krathsh */
                                    /* kai o vroxos diakoptetai */
                }
            }
                if (found!=1 && found!=2 && lewf[bus_seats-1]==0) /* An oles oi ueseis sta parathyra */
                                    /* einai krathmenes ginetai elegxos kai gia to deji parathyro ths */
                                    /* galarias */
                {
                    lewf[bus_seats]==1;
                    found=3;        /* An den einai krathmenh, exoyme eyresh, ginetai krathsh */
                                    /* kai o vroxos diakoptetai */
                }
                if (found==1) /* An vreuhke eleyuerh uesh se aristero parathyro */
                {
                    printf("H uesh %d dipla sto parathyro einai pleon kateilhmmenh.\n",i+1);
                }
                else if (found==2) /* An vreuhke eleyuerh uesh se deji parathyro */
                {
                    printf("H uesh %d dipla sto parathyro einai pleon kateilhmmenh.\n",i+4);
                }
                else if (found==3) /* An vreuhke eleyuerh uesh sto teleytaio parathyro */
                {
                    printf("H uesh %d dipla sto parathyro einai pleon kateilhmmenh.\n",bus_seats);
                }
                else /* An oles oi ueseis se parathyro einai kateilhmmenes */
                {
                    printf("Den yparxei kenh uesh dipla se parathyro.\n");
                }
                puts("\n");
                goto menu;
        }
        else if (epilogh=='4')
        {
            int akyr; /* Metablhth gia thn epiuymhth uesh akyrwshs */
            printf("Dwse th uesh poy ueleis na akyrwseis: ");
            scanf("%d",&akyr);
            if (akyr<=0 || akyr>bus_seats) /* Elegxos an o arithmos poy doueike einai ektos oriwn */
            {
                printf("Edwses lathos arithmo ueshs.\n");
            }
            if (akyr>0 && akyr<=bus_seats && lewf[akyr-1]==0) /* Elegxos an h uesh den einai krathmenh */
            {
                printf("H uesh me arithmo %d den einai krathmenh.\n",akyr);
            }
            if (akyr>0 && akyr<=bus_seats && lewf[akyr-1]==1) /* An h uesh einai entos oriwn kai einai */
                                                              /* krathmenh, ginetai akyrwsh */
            {
                lewf[akyr-1]=0;
                printf("H krathsh ths ueshs me arithmo %d akyrwuhke\n",akyr);
            }
            puts("\n");
            goto menu; /* Epanafora sto menoy */
        }
        else if (epilogh=='5')
        {
            int anaz; /* Metablhth gia thn anazhthsh krathmenhs 'h mh ueshs */
            printf("Dwse th uesh poy se endiaferei: ");
            scanf("%d",&anaz);
            if (anaz<=0 || anaz>bus_seats) /* Elegxos an o arithmos poy doueike einai ektos oriwn */
            {
                printf("Edwses lathos arithmo ueshs.\n");
            }
            if (anaz>0 && anaz<=bus_seats && lewf[anaz-1]==0) /* Elegxos an h uesh den einai krathmenh */
            {
                printf("H uesh me arithmo %d den einai krathmenh.\n",anaz);
            }
            if (anaz>0 && anaz<=bus_seats && lewf[anaz-1]==1) /* Elegxos an h uesh einai entos oriwn kai einai */
                                                              /* krathmenh */
            {
                printf("H uesh me arithmo %d einai krathmenh.\n",anaz);
            }
            puts("\n");
            goto menu; /* Epanafora sto menoy */
        }
        if (epilogh=='6')
        {
            printf("Oi arithmoi twn krathmenwn uesewn einai:");
            for (i=0; i<bus_seats; i++)
            {
                if (lewf[i]==1) /* Elegxos an h uesh einai krathenh */
                {
                    printf("%d ",i+1);
                }
            }
            puts("\n"); goto menu; /* Phgainei sthn etiketa menu gia na janodouei to menoy */
        }
        else if (epilogh=='7')
        {
            puts("\n");
            char ch1='*',ch2='_'; /* Xarakthres * kai _ gia tis krathmenes */
                                  /* kai kenes ueseis antistoixa */
            bus=fopen("bus.txt","r"); /* Anoigma toy arxeioy bus */
            if (bus==NULL)  /* Elegxos an h fopen eixe problhma na anoijei to arxeio */
            {
                puts("To arxeio den anoigei"); /* An exei problhma emfanizei mhnyma */
                exit(2);
            }
            for (i=1; i<=7; i++)
            {
                fscanf(bus,"%c",&bus_sign);
                printf("%c",bus_sign);    /* Emfanish ths pinakidas */
            }
            puts("\n");
            int j; /* Metrhths seirwn */
            for (j=0; j<bus_seats-5; j=j+4)
            {
                if (lewf[j]==1) /* Elegxos an h uesh j ths prwths sthlhs einai kratmenh */
                {
                    printf("%c",ch1); /* An einai krathmenh emfanizei * */
                }
                else
                {
                    printf("%c",ch2); /* An den einai krathmenh emfanizei _ */
                }
                if (lewf[j+1]==1) /* Elegxos an h uesh j+1 ths deyterhs sthlhs einai krathmenh */
                {
                    printf("%c ",ch1); /* mpainei keno meta th deyterh sthlh gia ton diadromo */
                }
                else
                {
                    printf("%c ",ch2);
                }
                if (lewf[j+2]==1)  /* Elegxos an h uesh j+2 ths triths sthlhs einai krathmenh */
                {
                    printf("%c",ch1);
                }
                else
                {
                    printf("%c",ch2);
                }
                if (lewf[j+3]==1)  /* Elegxos an h uesh j+3 ths tetarths sthlhs einai krathmenh */
                {
                    printf("%c",ch1);
                }
                else
                {
                    printf("%c",ch2);
                }
            puts("\n");
            }
            for (j=bus_seats-5; j<=bus_seats-1; j++) /* Broxos gia tis 5 ueseis ths galarias */
            {
                if (lewf[j]==1) /* Elegxos an h uesh j einai krathmenh */
                {
                    printf("%c",ch1);
                }
                else
                {
                    printf("%c",ch2);
                }
            }
            puts("\n"); goto menu;
        }
        else if (epilogh=='8')
        {
            char ch1='*',ch2='_';
            layout=fopen("layout.txt","w"); /* Anoigma toy arxeioy layout */
            bus=fopen("bus.txt","r");       /* Anoigma toy arxeioy bus */
            if (bus==NULL)  /* Elegxos an h fopen eixe problhma na anoijei to arxeio bus */
            {
                puts("To arxeio den anoigei"); /* An exei problhma emfanizei mhnyma */
                exit(2);
            }
            for (i=1; i<=7; i++)
            {
                fscanf(bus,"%c",&bus_sign);
                fprintf(layout,"%c",bus_sign);/* Eggrafh ths pinakidas sto arxeio layout */
            }
            fprintf(layout,"\n"); /* Allazei grammh */
            int j; /* Metrhths seirwn */
            for (j=0; j<bus_seats-5; j=j+4)
            {
                if (lewf[j]==1) /* Elegxos an h uesh j ths prwths sthlhs einai krathmenh */
                {
                    fprintf(layout,"%c",ch1); /* An einai krathmenh ginetai ektypvsh * sto */
                                              /* arxeio layout */
                }
                else
                {
                    fprintf(layout,"%c",ch2); /* An den einai krathmenh ginetai ektypwsh _ sto arxeio */
                }                             /* layout */
                if (lewf[j+1]==1) /* Elegxos an h uesh j+1 ths deyterhs sthlhs einai krathmenh */
                {
                    fprintf(layout,"%c ",ch1);
                }
                else
                {
                    fprintf(layout,"%c ",ch2);
                }
                if (lewf[j+2]==1) /* Elegxos an h uesh j+2 ths triths sthlhs einai krathmenh */
                {
                    fprintf(layout,"%c",ch1);
                }
                else
                {
                    fprintf(layout,"%c",ch2);
                }
                if (lewf[j+3]==1) /* Elegxos an h uesh j+3 ths tetarths sthlhs einai krathmenh */
                {
                    fprintf(layout,"%c\n",ch1);
                }
                else
                {
                    fprintf(layout,"%c\n",ch2);
                }
            }
            for (j=bus_seats-5; j<=bus_seats-1; j++) /* Broxos gia elegxo twn uesewn ths galarias */
            {
                if (lewf[j]==1)
                {
                    fprintf(layout,"%c",ch1);
                }
                else
                {
                    fprintf(layout,"%c",ch2);
                }
            }
                puts("\n");
                printf("H pinakida kykloforias kai to diagramma toy\n");
                printf("lewforeioy apouhkeythkan sto arxeio layout.txt.\n");
                puts("\n");
        }
        else
        {
            printf("\nTermatismos programmatos\n\n"); /* Sthn epilogh 0 poy exei apomeinei */
                                                      /* to programma termatizetai */
        }
    }
    else /* An douei arithmos epiloghs ektos oriwn, emfanizetai mhnyma lathoys */
    {
    printf("Edwses lathos epilogh.\n");
    puts("\n"); goto menu;
    }
	system("pause");
}


