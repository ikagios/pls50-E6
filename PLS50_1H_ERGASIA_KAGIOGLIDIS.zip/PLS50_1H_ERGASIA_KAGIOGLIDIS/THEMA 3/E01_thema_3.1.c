#include <stdio.h> /*Gia synarthseis eisodoy-ejodoy scanf() kai printf() */

main()
{
	int ar,phl,ypol; /* Akeraioi vste oi diareseis na mhn afhnoyn ypoloipo */
	char ch; /* Gia th metatroph toy ypoloipoy se xarakthra */
	const int stath=2; /* Stathera gia toys sxetikoys ypologismoys */
	printf("Dose ena uetiko akeraio arithmo:");
    neos_arithmos: /* Etiketa opoy ua epistrecei h entolh goto an ar<=0 */
    scanf("%d",&ar);/* Eisagwgh akeraioy apo to plhktrologio */
        do
        {
            ar=(ar>0)?ar:0; /* Elegxos an ua douei uetikos akeraios */
            /* An douei arnhtikos ;h mhden tote typika dinetai sto ar h timh 0 */
            if (ar==0)      /* Sthn periptwsh poy ar<=0 */
            {
                printf("Edwses arnhtiko arithmo 'h mhden\n"); /* Dinetai sxetiko mhnyma */
                printf("Dwse neo arithmo\n"); goto neos_arithmos; /* To goto metaferei */
                                                            /* ton elegxo sthn etiketa */
            }
            phl=ar/stath; /* Ypologizei to ypoloipo toy trexonta arithmoy me th stathera=2 */
            ypol=ar%stath; /* Ypologizei to ypoloipo ths diaireshs toy ar me th stath=2 */
            ch=(ypol==1)?'1':'0'; /* Elegxos: an to ypoloipo einai 1 o xarakthras ginetai */
                                  /* '1', enw an to ypoloipo einai 0 ginetai '0' */
            putchar(ch); /* Ektypwsh toy xarakthra '1' 'h '0' antistoixa, poy apotelei */
                         /* ligotero shmantiko chfio apo to epomeno */
            ar=phl; /* O trexwn arithmos lambanei thn timh toy phlikoy */
        }
        while (phl!=0); /* H diadikasia epanalambanetai mexri to phliko na labei timh 0 */
        putch('\n'); /* Allagh grammhs meta thn ektypwsh toy antistrofoy dyadikoy arithmoy */
        system("pause");
}


