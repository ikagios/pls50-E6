#include <stdio.h>  /* Gia tis synarthseis eisodoy-ejodoy printf() */
                    /* kai scanf() */
main()
{
	float a,b,sum,sub,gin,phl; /* dhlwsh metablhtwn kinhths ypodiastolhs */
	char c,c1,c2;  /* dhlwsh xarakthrwn gia elegxo arithmhtikhs prajhs */
	               /* kai kenwn diasthmatvn*/
	printf("Dose arithmo prajh kai arithmo me kena metajy toys: ");
	scanf("%f%c%c%c%f",&a,&c1,&c,&c2,&b); /* eisagwgh arithmoy_kenoy_prajhs_ */
                                          /* kenoy_arithmoy */
	if(c1==' ' && c2==' ') /* elegxos eisagwghs kenwn metajy arithmoy kai prajhs */
    {
        if(c=='+') /* an sthn prajh eisaxuei '+' ekteleitai prosuesh */
        {
		sum=a+b;
		printf("To apotelesma ths prostheshs einai: %f\n",sum);
        }
        else if (c=='-') /* an sthn prajh eisaxuei '-' ekteleitai afairesh */
        {
		sub=a-b;
		printf("To apotelesma ths afaireshs einai: %f\n",sub);
        }
        else if (c=='x' || c=='X' || c=='*')  /* an sthn prajh eisaxuei 'x' */
                                   /* 'X' 'h '*' ekteleitai pollaplasiasmos */
        {
        gin=a*b;
        printf("To apotelesma toy poallaplasiasmoy einai: %f\n",gin);
        }
        else if (c=='/') /* an sthn prajh eisaxuei'/' ekteleitai diairesh */
        {
            if (b!=0)  /* elegxos gia diairesh me to mhden */
            {
            phl=a/b;
            printf("To apotelesma ths diaireshs einai: %f\n",phl);
            }
            else
            {
            printf("Epixeirhte diairesh me to mhden - Lathos\n"); /* an o diaireths */
                                          /* einai mhden emfanizetai mhnyma lathoys */
            }
        }
        else
        {
        printf("H prajh den einai swsth\n"); /* an sthn prajh eisaxuei allos xarakthras */
                        /* peran twn '+','-','x','X','*','/' emfanizetai mhnyma lathous */
        }
    }
    else
    {
    fflush(stdin);
    printf("Den ebales kena\n"); /* an sth uesh twn kenwn eisaxuei allos xarakthras */
                                 /* emfanizetai to sxetiko mhnyma */
    }
    system("pause");
}


